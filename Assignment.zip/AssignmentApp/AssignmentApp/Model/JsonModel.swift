//
//  JsonModel.swift
//  AssignmentApp
//
//  Created by Pushpendra Patel on 09/10/22.
//  Copyright © 2022 Pushpendra Patel. All rights reserved.

import Foundation

// its for ViewController
struct JsonModel{
    var artistName: String = ""
    var trackCensoredName: String = ""
    var artworkUrl100: String = ""
    init(){
        
    }
    
    init(json:JSON){
        artistName = json["artistName"].stringValue
        trackCensoredName = json["trackCensoredName"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
    }
}

// wisdomleaf
/*
"id":"20",
"author":"Aleks Dorohovich",
"width":3670,
"height":2462,
"url":"https://unsplash.com/photos/nJdwUHmaY8A",
"download_url":"https://picsum.photos/id/20/3670/2462"
*/
struct JsonModelWisdom{
    
    var author: String = ""
    var id: String = ""
    var width: String = ""
    var height: String = ""

    var url: String = ""
    var download_url: String = ""
    
    init(){
        
    }
    
    init(json:JSON){
        author = json["author"].stringValue
        id = json["id"].stringValue
        width = json["width"].stringValue
        height = json["height"].stringValue

        download_url = json["download_url"].stringValue
        url = json["url"].stringValue

    }
}


// its for UserVC
struct UserJsonModel{
    
    var name: String = ""
    var username: String = ""
    var email: String = ""
    // var address: address
    
    init(json:JSON){
        
        name = json["name"].stringValue
        username = json["username"].stringValue
        email = json["email"].stringValue
        // address = address
    }
}

/*
    struct address{

        let street: String = ""
        let city: String = ""
        let zipcode: String = ""
      //  let geo: Geo

        init(json:JSON){

            street = json["street"].stringValue
            city = json["city"].stringValue
            zipcode = json["zipcode"].stringValue
        }
    }
*/

struct UserLoadingModel: Codable{
    let name: String
    let website: String
    let address: UserAddress
    let company: Usercompany
}
struct UserAddress: Codable{
    let street: String
    let city: String
    let zipcode: String
    let geo: Geo
}
struct Usercompany: Codable{
    let name: String
    let bs: String
}
struct Geo: Codable{
    let lat: String
    let lng: String
}


// CV model

struct UserCVModel: Codable{
    let artistName: String
    let artworkUrl100: String
    
}

/*
 {
 "id": 1,
 "name": "Leanne Graham",
 "username": "Bret",
 "email": "Sincere@april.biz",
 "address": {
 "street": "Kulas Light",
 "suite": "Apt. 556",
 "city": "Gwenborough",
 "zipcode": "92998-3874",
 "geo": {
 "lat": "-37.3159",
 "lng": "81.1496"
 }
 },
 "phone": "1-770-736-8031 x56442",
 "website": "hildegard.org",
 "company": {
 "name": "Romaguera-Crona",
 "catchPhrase": "Multi-layered client-server neural-net",
 "bs": "harness real-time e-markets"
 }
 
 */

/*
 struct User: Codable {
 var id: Int
 var name: String
 var username: String
 var email: String
 var address: Address
 
 enum CodingKeys: String, CodingKey {
 
 case id, name, username, email
 case Address = "address"
 
 }
 }
 
 struct Address: Codable {
 
 var street: String
 var city: String
 var geo: Geo
 
 enum CodingKeys: String, CodingKey {
 
 case street, city
 case Geo = "geo"
 }
 }
 struct Geo: Codable {
 
 var lat: Int
 var lng: Int
 }
 
 struct User1: Codable{
 
 let page: String
 let total: Int
 let data: [data]
 
 }
 struct data: Codable{
 
 let id: Int
 let email: String
 let first_name: String
 let last_name: String
 let avatar: String
 
 }
 
 /*
  // codable use
  https://blog.logrocket.com/simplify-json-parsing-swift-using-codable/
  {
  "results":{
  "suggestions":[
  {
  "kind":"terms",
  "searchTerm":"the weeknd",
  "displayTerm":"the weeknd"
  },
  {
  "kind":"terms",
  "searchTerm":"the weeknd & swedish house mafia",
  "displayTerm":"the w=eeknd & swedish house mafia"
  },
  {
  "kind":"terms",
  "searchTerm":"weeknd nigth",
  "displayTerm":"weeknd nigth"
  },
  {
  "kind":"terms",
  "searchTerm":"weeknd warriorz",
  "displayTerm":"weeknd warriorz"
  },
  {
  "kind":"terms",
  "searchTerm":"yeyo weeknd",
  "displayTerm":"yeyo weeknd"
  }
  ]
  }
  }
  */
 
 ////////////// Codable is combination of Encodale and Decodale.
 
 // Encodabble ==  Json to Swift
 // Decodable ==  Swift to JSON
 
 
 struct Suggestions: Codable {
 let results: Results
 
 struct Results: Codable {
 let suggestions: [Suggestion]
 }
 }
 
 struct Suggestion: Codable {
 let kind: String
 let searchTerm: String
 let displayTerm: String
 }
 
 */

/*
 ////////////////    Singleton Class    //////////////////////////
 link : https://medium.com/@nimjea/singleton-class-in-swift-17eef2d01d88
 
 class LocationManager{
 
 static let shared = LocationManager()
 
 init(){}
 
 func requestForLocation(){
 //Code Process
 print("Location granted")
 }
 
 }
 
 //Access class function with Singleton Pattern 🚀
 LocationManager.shared.requestForLocation()  //"Location granted"
 //Still you can use your class like this
 let location = LocationManager()
 location.requestForLocation()
 
 */
/*
 class LocationManager{
 
 static let shared = LocationManager()
 
 var locationGranted: Bool?
 //Initializer access level change now
 private init(){}
 
 func requestForLocation(){
 //Code Process
 locationGranted = true
 print("Location granted")
 }
 
 }
 // Access class function in a single line
 LocationManager.shared.requestForLocation()
 
 */

class LocationManager{
    
    static let shared = LocationManager()
    
    var locationgranted : Bool?
    
    private init(){}
    
    func requestForlocation(){
        
        print("Location Access")
        locationgranted = true
        print("location granted")
    }
}

// let location  = LocationManager()
// location.requestForlocation()


//  viewcontroller last API
struct Post:Codable{
    let userId: Int
    let id: Int
    let title: String
    let body: String
    
}
