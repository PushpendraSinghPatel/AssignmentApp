//
//  WisdomLeafVC.swift
//  AssignmentApp
//
//  Created by MD on 12/06/23.
// create section for 10 rows in each refres
// https://stackoverflow.com/questions/28206492/refresh-certain-row-of-uitableview-based-on-int-in-swift

// https://stackoverflow.com/questions/35367496/swift-tableview-pagination

//  project link for Github
// https://github.com/PushpendraSinghPatel/Assignment.git

import UIKit
import Kingfisher
import Alamofire

class WisdomLeafVC: UIViewController {

    var currentPage : Int = 0
    var isLoadingList : Bool = false

    var rowForScroll = 1


    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var loadingView: UIView! {
        didSet {
            loadingView.layer.cornerRadius = 6
        }
    }
    
    var arrmyData = [JsonModelWisdom]()
    
    @IBOutlet var tv: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        tv.delegate=self //To enable scrollviewdelegate

      //  jsonParsing()
        getListFromServer()
        // Do any additional setup after loading the view.
    }
    
    func showSpinner() {
        activityIndicator.startAnimating()
        loadingView.isHidden = false
    }
    
    func hideSpinner() {
        activityIndicator.stopAnimating()
        loadingView.isHidden = true
    }
    
    /*
    // Pagination
    func getListFromServer(_ pageNumber: Int){
      //  getListFromServer()
        self.isLoadingList = false
        self.tv.reloadData()
    }
    
    func loadMoreItemsForList(){
        currentPage += 1
        getListFromServer(currentPage)
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (((scrollView.contentOffset.y + scrollView.frame.size.height) > scrollView.contentSize.height ) && !isLoadingList){
            self.isLoadingList = true
            self.loadMoreItemsForList()
        }
    }
*/
    



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension WisdomLeafVC {
    
 //   func jsonParsing(){
        
    func getListFromServer(){
        self.showSpinner()
   //   let url = URL(string: "https://jsonplaceholder.typicode.com/users")
        let url = URL(string: "https://picsum.photos/v2/list?page=2&limit=20")

        URLSession.shared.dataTask(with: url!) { [self] (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                let results = json[]
                                
                for arr in results.arrayValue{
                    print(arr)
                    
                    self.arrmyData.append(JsonModelWisdom(json: arr))
                }
                DispatchQueue.main.async {
                     self.tv.reloadData()
                }
                self.hideSpinner()
                
            }catch{
                print(error.localizedDescription)
            }
        }.resume()
    }
}

extension WisdomLeafVC: UITableViewDelegate, UITableViewDataSource{
    
//    let indexPathRow:Int = 0
//    let indexPosition = IndexPath(row: indexPathRow, section: 0)
//    tableView.reloadRows(at: [indexPosition], with: .none)


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrmyData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WisdomTVCell", for: indexPath) as! WisdomTVCell
        
        cell.lblID.text = arrmyData[indexPath.row].id
        cell.lblAuther.text = arrmyData[indexPath.row].author
       
        let strhight = arrmyData[indexPath.row].height
        cell.lblhight.text = "Height : \(strhight)"

        let strwidth = arrmyData[indexPath.row].width
        cell.lblwidth.text = "Width : \(strwidth)"

        
        let StrUrl = arrmyData[indexPath.row].download_url
       // let StrUrl = "https://reqres.in/img/faces/10-image.jpg"
        cell.userImg.kf.setImage(with: URL(string: "\(StrUrl)"))
            
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       // let array_user = arrmyData[indexPath.row]
        let strAuther = arrmyData[indexPath.row].author
        print(strAuther)
    }
    
    
}
