//
//  WisdomTVCell.swift
//  AssignmentApp
//
//  Created by MD on 12/06/23.
//

import UIKit

class WisdomTVCell: UITableViewCell {

    @IBOutlet var lblAuther: UILabel!
    @IBOutlet var lblhight: UILabel!
    @IBOutlet var lblwidth: UILabel!
    @IBOutlet var lblID: UILabel!
    
    @IBOutlet var userImg: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
